public class Box implements Comparable<Box>{
    private int size;

    public Box(int size) {
        this.size = size;
    }

    public int getSize() {
        return size;
    }

//    @Override
//    public int compareTo(Object o){
//        if (o instanceof Box){
//            throw new IllegalArgumentException("Тип не тот");
//        }
//        Box another = (Box) o;
//        return this.size - another.size;
//    }

    public int compareTo(Box o){
        return this.size - o.size;
    }
}
