public class BoxGen <T>{
    // T - type
    // E - element collection
    // K - key
    // V - value
    // N - number
    // нельзя примитивы только ссылочные типы данных
    // <Е, К> - можно несколько типов, но желательно не больше 3
    // в коде нельзя создавать экземпляр класса Т t1 = new T();
    // нельзя создать массив обьектов T[] t1 = new T
    // нельзя static T  потому что она будет принадлежать классу BoxGen с разными Т
    // нельзя создавать обобщенные исключения
    //
    private T obj;

    public BoxGen(T obj) {
        this.obj = obj;
    }

    public T getObj() {
        return obj;
    }

    public void setObj(T obj) {
        this.obj = obj;
    }
}
