public class BoxWithNumbers<T extends Number> { // ограничение сверху типа Т
    private T[] arr; // обьявляем ссылку на массив типа Т


    public BoxWithNumbers(T... arr) {
        this.arr = arr;
    }

    public double avg(){
        double d = 0.0; //создаем переменную типа дабл
        for (int i = 0; i < arr.length; i++) { // проходим циклом по массиву
          d+=arr[i].doubleValue();  // и все элементы к д добаляем// черех точечный синтаксис так как класс Т наследуется
            // от намбер используем метод .doubleValue()
        }
        d /= arr.length; // вычисляем среднее арифметическое

        return d;
    }

    public boolean sameAvg(BoxWithNumbers<?> another){ // знак вопроса это значит любой
//        return this.avg() == another.avg(); //никогда не сравнивать дабл и флот через равно равно
        return Math.abs(this.avg() - another.avg()) < 0.00001; // сравнивать только через модуль разности
    }
}
