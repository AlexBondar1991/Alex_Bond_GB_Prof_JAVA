package HW_1_Generick;

import HW_1_Generick.fruits.Fruit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BoxOfFruits<T extends Fruit> { // в данном классе могут храниться только фрукты и наследники
    private List<T> container; // хранить будем в листе

    public BoxOfFruits()
    {this.container = new ArrayList<>(); // при создании инициализируем контейнер новым пустым ArrayList
    }

    public BoxOfFruits(T...fruits) // метод для передачи фруктов сразу в ArrayList
    {this.container = new ArrayList<>(Arrays.asList(fruits));}

    public float getWeight(){ // метод возвращения веса

        float w = 0.0f;

        for (T fruit : container){
            w = w + fruit.getWeight();
        }
        return w;
    }

    public boolean someAvg(BoxOfFruits<?> another){ // нельзя сравнивать float b doublle без Math.abs так как будут ошибки округления
        return Math.abs(this.getWeight() - another.getWeight()) < 0.0001;
    }

    public void transfer (BoxOfFruits<? super T> another){
        if (another == this){
            return;
        }

        another.container.addAll(this.container);
        this.container.clear();
    }

    public void add(T fruit){
        container.add(fruit);
    }

}
