package HW_1_Generick;

import HW_1_Generick.fruits.Apple;

import java.util.*;


public class MyMain {
    public static void main(String[] args) {
        // task 3
        BoxOfFruits<Apple> box = new BoxOfFruits<>();

        /*
        Task 2 Написать метод, который преобразует массив в ArrayList;
         */
        String[] arrayOfString = {"1","2","3","4","5",}; //создаем массив и задаем конкретные значения для его элементов
        ArrayList<String> listOfString = arrayToList(arrayOfString); // создаем строковый ArrayList и присваиваем ему значение
        // метода arrayToList

    }
    // Task 1
    public static final <T> void swap(T[] a, int indx1,int indx2 ){
        T t = a[indx1];
        a[indx1] = a[indx2];
        a[indx2] = t;
    }
    // Task 1 another method
    //при помощи того же метода asList делаем- List<String> l = new ArrayList<String>(Arrays.asList(a));
    //swap(l, 0, 1);
    public static final <T> void swap (List<T> l, int indx1,int indx2) {
        Collections.<T>swap(l,indx1,indx2);
    }

        /*
        Task2
       Написать метод, который преобразует массив в ArrayList;

       Список, возвращаемый из asList, будет иметь фиксированный размери и если мы захотим
       добавлять или удалять элементы из возвращаемого списка в этом коде, то нужно будет
       обернуть его в новый ArrayList. Получается не совсем практично.
        */
    public static <T> ArrayList <T> arrayToList(T[] arrayOfString) { // метод преобразует массив в ArrayList
        return new ArrayList<>(Arrays.asList(arrayOfString)); // при выполнении возвращается ArrayList через метод Arrays.asList
    }
}
