package HW_1_Generick.fruits;

public class Apple extends Fruit {
    public Apple(){super(1.0f);}
}
