package HW_1_Generick.fruits;

public abstract class Fruit { // создаем абстрактный класс с фруктом
    private float weight; // добавляем поле с весом для фрукта

    protected Fruit(float weight) { // используем конструктор для передачи веса
        this.weight = weight;
    }

    public float getWeight(){return weight;} // метод для возвращения веса фрукта


}
