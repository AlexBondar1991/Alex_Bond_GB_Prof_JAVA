package HW_1_Generick.fruits;

public class Orange extends Fruit{
    public Orange(){super(1.8f);}
}
