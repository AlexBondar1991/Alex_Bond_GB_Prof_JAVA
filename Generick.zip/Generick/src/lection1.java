import java.util.*;

public class lection1 {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>(Arrays.asList(10,20,30));

        System.out.println(sumListElements(numbers));

        int x = getFirstElement(numbers);






//       BoxGen<Integer> bg1 = new BoxGen<>(10);
//       BoxGen<Integer> bg2 = new BoxGen<>(20);
//
//
//       int sum = bg1.getObj() + bg2.getObj();
//        System.out.println("sum= " + sum);
//
//        BoxGen<String> bs = new BoxGen<>("Java");
//        bs.setObj("new java");
//
//        System.out.println(bg1.getClass()); // не покажет класс так как он стирается в байт коде
    }

    public static <T> T getFirstElement(List<T> list){
        return list.get(0);
    }

    public static double sumListElements(List<? extends Number> numbers){
        double d = 0.0;
        for (int i = 0; i < numbers.size(); i++) {
           d+=numbers.get(i).doubleValue();
        }
        return d;
    }

    private void notCompareLikeThat(){
        double a = 0.7;
        double b = 0.0;
        for (int i = 0; i < 70; i++) {
            b += 0.01;
        }

        System.out.println(a == b);
        System.out.println("a = " + a);
        System.out.println("b = " + b);
        System.out.println(Math.abs(a - b) < 0.000001);
    }

    public void exBoxWithNumbers(){
        BoxWithNumbers<Float> boxFloat1 = new BoxWithNumbers<>(10.f, 20.f,30.f);
        BoxWithNumbers<Float> boxFloat2 = new BoxWithNumbers<>(10.f, 20.f,30.f);
        System.out.println(boxFloat1.avg());
        System.out.println(boxFloat2.avg());
        System.out.println(boxFloat1.sameAvg(boxFloat2));


        BoxWithNumbers<Integer> boxInteger = new BoxWithNumbers<>(10, 20, 30);
        System.out.println(boxInteger.avg());
    }

    public void exBoxGen(){
        BoxGen<Integer> bg1 = new BoxGen<>(10);
        BoxGen<Integer> bg2 = new BoxGen<>(20);


        int sum = bg1.getObj() + bg2.getObj();
        System.out.println("sum= " + sum);

        BoxGen<String> bs = new BoxGen<>("Java");
        bs.setObj("new java");

        System.out.println(bg1.getClass()); // не покажет класс так как он стирается в байт коде
    }

    private void exSimpleBox(){
        SimpleBox box1 = new SimpleBox(10);
        SimpleBox box2 = new SimpleBox(20);

///////
        box1.setObj("java");
///////
        if (box1.getObj() instanceof Integer && box2.getObj() instanceof Integer) {
            int sum = (int) box1.getObj() + (int) box2.getObj();
            System.out.println("sum= " + sum);
        }
    }
}
